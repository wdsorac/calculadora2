
package com.mycompany.logincalculadora;

    
public class Logincalculadora {

    public static void main(String[] args) {
        FormLogin objetoLogin = new FormLogin();
        objetoLogin.setVisible(true);
    }
}
    